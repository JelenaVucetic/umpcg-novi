<!DOCTYPE html>
<html lang="<?php echo e(app()->getLocale()); ?>">
<head>
    <meta charset="utf-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1">

    <meta property="og:image" content="http://umpcg.qqriq.me/img/logo.jpg" />
    <meta property="og:type" content="website" />
    <meta property="og:url" content="http://umpcg.qqriq.me/" />

    <link rel="shortcut icon" type="image/x-icon" href="/img/logo_icon.ico" />
    <!-- CSRF Token -->
    <meta name="csrf-token" content="<?php echo e(csrf_token()); ?>">

    <title><?php echo e(config('app.name', 'Laravel')); ?></title>

    <!-- Styles -->
    <link href="<?php echo e(asset('css/app.css')); ?>" rel="stylesheet">
    <link href="<?php echo e(asset('font-awsome/css/font-awesome.min.css')); ?>" rel="stylesheet">
    <link href="<?php echo e(asset('css/acordian.css')); ?>" rel="stylesheet">
    <link href="<?php echo e(asset('css/carousel.css')); ?>" rel="stylesheet">
    <link href="<?php echo e(asset('css/jcarousel.responsive.css')); ?>" rel="stylesheet">
    <link href="<?php echo e(asset('css/nav.css')); ?>" rel="stylesheet">
    <link href="<?php echo e(asset('css/footer.css')); ?>" rel="stylesheet">
    <link href="<?php echo e(asset('css/posts.css')); ?>" rel="stylesheet">
    <link href="<?php echo e(asset('css/singlePost.css')); ?>" rel="stylesheet">
    <link href="<?php echo e(asset('css/about.css')); ?>" rel="stylesheet">
    <link href="<?php echo e(asset('css/becomeMember.css')); ?>" rel="stylesheet">
    <link href="<?php echo e(asset('css/eBooks.css')); ?>" rel="stylesheet">
    <link href="<?php echo e(asset('css/members.css')); ?>" rel="stylesheet">
    <link href="<?php echo e(asset('css/activities.css')); ?>" rel="stylesheet">
    <link href="<?php echo e(asset('css/admin-nav.css')); ?>" rel="stylesheet">
    <link href="<?php echo e(asset('css/dashboard.css')); ?>" rel="stylesheet">
    <link href="<?php echo e(asset('css/carousel.css')); ?>" rel="stylesheet">
    <link href="https://fonts.googleapis.com/css?family=Roboto&display=swap" rel="stylesheet">
</head>
<style>
    @media  only screen and (max-width : 760px) {
    #myBtn {
        display: none !important;
    }
}
</style>
<body style="font-family: 'Roboto'; background-color:white !important;">
    <div id="app">
        <img src="/img/Ikonica za povratak na vrh.svg" alt="" onclick="topFunction()" id="myBtn" title="Go to top">
        <?php echo $__env->make('inc.navbar', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
        <div class="container">
            <?php echo $__env->make('inc.messages', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
            <?php echo $__env->yieldContent('content'); ?>
        </div>
        <?php echo $__env->yieldContent('members'); ?>
        <?php echo $__env->yieldContent('carousel'); ?>
        <?php echo $__env->yieldContent('breadcrumbs'); ?>
        <?php echo $__env->make('inc.footer', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
    </div>

    <!-- Scripts -->
    <script src="<?php echo e(asset('js/app.js')); ?>"></script>
    <script src="<?php echo e(asset('js/jcarousel.responsive.js')); ?>"></script>
    <script src="<?php echo e(asset('js/jquery.jcarousel.js')); ?>"></script>
    <script src="<?php echo e(asset('js/jquery.js')); ?>"></script>
    <script src="/vendor/unisharp/laravel-ckeditor/ckeditor.js"></script>
    <?php echo $__env->yieldContent('boostrap-script'); ?>
    <?php echo $__env->yieldContent('fixed-column-script'); ?>
    <script>
        CKEDITOR.replace( 'article-ckeditor' );
    </script>
    <script>
        //Get the button
        var mybutton = document.getElementById("myBtn");

        // When the user scrolls down 20px from the top of the document, show the button
        window.onscroll = function() {scrollFunction()};

        function scrollFunction() {
        if (document.body.scrollTop > 20 || document.documentElement.scrollTop > 20) {
            mybutton.style.display = "block";
        } else {
            mybutton.style.display = "none";
        }
        }

        // When the user clicks on the button, scroll to the top of the document
        function topFunction() {
        document.body.scrollTop = 0;
        document.documentElement.scrollTop = 0;
        }
</script>
<script>
    $('textarea').keyup(updateCount);
    $('textarea').keydown(updateCount);

    function updateCount() {
        var cs = $(this).val().length;
        $('#characters').text(cs);
    }
</script>
<script>
    $('#title').keyup(updateCount);
    $('#title').keydown(updateCount);

    function updateCount() {
        var cs = $(this).val().length;
        $('#char').text(cs);
    }
</script>
<script>
    $(function() {
        $(".random").html($(".random").children().sort(function() { return 0.5 - Math.random() }));
        });
</script>

<script>
    var input = document.getElementById( 'file-upload' );
    var infoArea = document.getElementById( 'file-upload-filename' );

    input.addEventListener( 'change', showFileName );

    function showFileName( event ) {
    
    // the change event gives us the input it occurred in 
    var input = event.srcElement;
    
    // the input has an array of files in the `files` property, each one has a name that you can use. We're just using the name here.
    var fileName = input.files[0].name;
    
    // use fileName however fits your app best, i.e. add it into a div
    infoArea.textContent = fileName;
    }
</script>
<script>
    $(window).scroll(function(){
    if ($(window).scrollTop() >= 107) {
        $('#navbar').addClass('fixed-header');
    }
    else {
        $('#navbar').removeClass('fixed-header');
    }
});

</script>

<script>
$('#delete').on('show.bs.modal', function (event) {
        var button = $(event.relatedTarget) // Button that triggered the modal
        var postId = button.data('post') // Extract info from data-* attributes
        // If necessary, you could initiate an AJAX request here (and then do the updating in a callback).
        // Update the modal's content. We'll use jQuery here, but you could use a data binding library or other methods instead.
        var modal = $(this)
        modal.find('.modal-content #p_id').val(postId) 
})
</script>

<script>
 $(function() {
    $(".wrapper2").mousewheel(function(event, delta) {
    this.scrollLeft -= (delta * 50);   
    event.preventDefault();

    });

    });
</script>

<script>

/*  $(document).ready(function() {
    var table = $('#example').DataTable( {     
    scrollX:        true,
    scrollCollapse: true,
    paging: false,
    "info": false,
    } );
} ); */

var table = $('#example').DataTable({
    paging: false,
    "info": false,
});

$('#myInputTextField').on( 'keyup', function () {
    table.search( this.value ).draw();
} );

</script>

<script>
    $(function(){
    $(".wrapper1").scroll(function(){
        $(".wrapper2")
            .scrollLeft($(".wrapper1").scrollLeft());
    });
    $(".wrapper2").scroll(function(){
        $(".wrapper1")
            .scrollLeft($(".wrapper2").scrollLeft());
    });
});
</script>

<script>
    function copyText(element) {
  var range, selection, worked;

  if (document.body.createTextRange) {
    range = document.body.createTextRange();
    range.moveToElementText(element);
    range.select();
  } else if (window.getSelection) {
    selection = window.getSelection();        
    range = document.createRange();
    range.selectNodeContents(element);
    selection.removeAllRanges();
    selection.addRange(range);
  }
  
  try {
    document.execCommand('copy');
    alert('text copied');
  }
  catch (err) {
    alert('unable to copy text');
  }
}
</script>

<script> 
function getCookie(name)
{
var start = document.cookie.indexOf( name + "=" );
var len = start + name.length + 1;
if ( ( !start ) && ( name != document.cookie.substring( 0, name.length ) ) ) {
return null;
}
if ( start == -1 ) return null;
var end = document.cookie.indexOf( ";", len );
if ( end == -1 ) end = document.cookie.length;
return unescape( document.cookie.substring( len, end ) );
}

function doload()
{
var scrollTop = getCookie ("scrollTop");
var scrollLeft = getCookie("scrollLeft");

if (!isNaN(scrollTop))
{
  document.body.scrollTop = scrollTop;
  document.documentElement.scrollTop = scrollTop;

}
if (!isNaN(scrollLeft))
{
        document.body.scrollLeft = scrollLeft;
        document.documentElement.scrollLeft = scrollLeft;
}

Delete_Cookie("scrollTop");
Delete_Cookie("scrollLeft");
setTimeout( "Refresh()", 120*1000 );
}

function Refresh()
{
document.cookie = 'scrollTop=' + f_scrollTop();
document.cookie = 'scrollLeft=' + f_scrollLeft();
document.location.reload(true);
}

//Setting the cookie for vertical position
function f_scrollTop() {
return f_filterResults (
window.pageYOffset ? window.pageYOffset : 0,
document.documentElement ? document.documentElement.scrollTop : 0,
document.body ? document.body.scrollTop : 0
);
}

function f_filterResults(n_win, n_docel, n_body) {
var n_result = n_win ? n_win : 0;
if (n_docel && (!n_result || (n_result > n_docel)))
n_result = n_docel;
return n_body && (!n_result || (n_result > n_body)) ? n_body : n_result;
}

//Setting the cookie for horizontal position
function f_scrollLeft() {
return f_filterResults (
window.pageXOffset ? window.pageXOffset : 0,
document.documentElement ? document.documentElement.scrollLeft : 0,
document.body ? document.body.scrollLeft : 0
);
}

function Delete_Cookie(name)
{
document.cookie = name + "=" + ";expires=Thu, 01-Jan-1970 00:00:01 GMT";

}

window.onload=doload;
</script>
</body>
</html>
