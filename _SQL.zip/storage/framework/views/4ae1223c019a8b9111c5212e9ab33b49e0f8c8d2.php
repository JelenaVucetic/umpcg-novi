<?php $__env->startSection('content'); ?>
<?php echo Breadcrumbs::render('activities'); ?>

<?php if(count($posts) > 0): ?>
           <?php 
           $rowCount = 0;
            ?>
           <div class="row">
            <?php $__currentLoopData = $posts; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $post): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <?php if( $rowCount == 5 ): ?>
               <div class="col-md-4" style="padding-top: 30px;">
                   <div class="postBox" style="background:none;box-shadow:none;padding: 70px 30px;">
                       <img src="/img/Baner-EYCA-UMPCG.png" style="border:none; width:100%">    
                   </div>
               </div>

               </div><div class="row">
               <div class="col-md-4" style="padding-top: 30px;">
                   <div class="postBox">
                   <a href="/posts/<?php echo e($post->id); ?>">
                   <span class="category" ></span>
                       <small style="color:#292663">Objavljeno: <?php echo e($post->date); ?>   </small>
                       <div id="imgDiv">
                       <img id="postImg" src="/storage/cover_image/thumbnail/<?php echo e($post->cover_image); ?>">
                       </div>
                       <h3><?php echo e($post->title); ?></h3>
                       <div>
                        <small> <img src="/img/Pregledi-ikonica copy.svg" style="margin-right: 7px;" alt=""><?php echo e($post->views); ?> pregleda</small>
                       </div>
                       </a>
                   </div>
               </div>
               <?php 
               $rowCount++;
                ?>
               <?php else: ?>
               <div class="col-md-4" style="padding-top: 30px;">
                   <div class="postBox">
                   <a href="/posts/<?php echo e($post->id); ?>">
                   <span class="category" ></span>
                       <small style="color:#292663">Objavljeno: <?php echo e($post->date); ?>   </small>
                       <div id="imgDiv">
                       <img id="postImg" src="/storage/cover_image/thumbnail/<?php echo e($post->cover_image); ?>">
                       </div>
                       <h3><?php echo e($post->title); ?></h3>
                       <div>
                        <small> <img src="/img/Pregledi-ikonica copy.svg" style="margin-right: 7px;" alt="" ><?php echo e($post->views); ?> pregleda</small>
                       </div>
                       </a>
                   </div>
               </div>
            
               <?php endif; ?>
               <?php 
               $rowCount++;
                ?>
              
               <?php if($rowCount % 3 == 0): ?>
                </div><div class="row">
               <?php endif; ?>
               
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
           </div>
        <?php echo e($posts->links()); ?>

    <?php else: ?>
        <p>No posts found</p>
    <?php endif; ?>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('breadcrumbs'); ?>
<div class="container-fluid" id='myBreadcrums'>
  <?php echo Breadcrumbs::render('activities'); ?>

</div>
<?php $__env->stopSection(); ?>


<?php echo $__env->make('layouts.app', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>