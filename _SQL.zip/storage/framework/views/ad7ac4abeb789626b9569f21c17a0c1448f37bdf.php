<div class="container-fluid footer">
    <p>Članovi Projekti E-books</p>
    <img src="/img/UMPCG_logo_bijeli.svg" alt="">
</div>