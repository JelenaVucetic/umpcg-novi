<?php $__env->startSection('fixed-column-script'); ?>
<script src="https://cdnjs.cloudflare.com/ajax/libs/jquery-mousewheel/3.1.13/jquery.mousewheel.min.js"></script>
<script src="/js/dataTables.js"></script>
<script src="/js/dataTables-fixedColumn.js"></script>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('members'); ?>
<div class="container">
<?php echo $__env->make('inc.admin_nav', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
</div>

<div class="searchMembers container-fluid">
  <label>Pretraži</label>
  <input type="text" id="myInputTextField">
</div>
<div class="container">

<div class="wrapper1">
  <div class="div1">
  </div>
</div>

<div class="wrapper2">
  <div class="div2">
    <table id="example" class="membersTable table">
    <thead>
      <tr>
        <th></th>
        <th class="th-lg">Logo</th>
        <th class="th-lg">Ime</th>
        <th class="th-lg">Prezime</th>
        <th class="th-lg">Jmbg</th>
        <th class="th-lg">Prebivalište</th>
        <th class="th-lg">Telefon</th>
        <th class="th-lg">E-mail</th>
        <th class="th-lg">Naziv firme</th>
        <th class="th-lg">Pib</th>
        <th class="th-lg">Datum osnivanja</th>
        <th class="th-lg">Adresa firme</th>
        <th class="th-lg">Web adresa</th>
        <th class="th-lg">Osnovna djelatnost</th>
        <th class="th-lg">Oblik organizacije</th>
        <th class="th-lg">Opis</th>
        <th class="th-lg">Facebook stranica</th>
        <th class="th-lg">Instagram stranica</th>
        <th class="th-lg">Status</th>
        <th class="th-lg">Akcija</th>
        <th class="th-lg" scope="col">Izmijeni</th>
        <th class="th-lg">Obriši</th>
      </tr>
    </thead>
    <tbody>
    <?php  $i=1;  ?>
    <?php $__currentLoopData = $members; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $member): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
      <tr id="component<?php echo e($member->id); ?>">
      <th scope="row"><?php  echo $i;  ?></th>
        <td><img id="" src="/img/<?php echo e($member->image); ?>" style="width:100px;"></td>
        <td class="td-lg"><div><?php echo e($member->firstname); ?></div></td>
        <td class="td-lg"><div><?php echo e($member->lastname); ?></div></td>
        <td class="td-lg"><div><?php echo e($member->jmbg); ?></div></td>
        <td class="td-lg"><div><?php echo e($member->place); ?></div></td>
        <td class="td-lg"><div><?php echo e($member->phone); ?></div></td>
        <td class="td-lg"><div><?php echo e($member->email); ?></div></td>
        <td class="td-lg"><div><?php echo e($member->company); ?></div></td>
        <td class="td-lg"><div><?php echo e($member->pib); ?></div></td>
        <td class="td-lg"><div><?php echo e($member->date); ?></div></td>
        <td class="td-lg"><div class="cell"><?php echo e($member->address); ?></div></td>
        <td class="td-lg"><div><?php echo e($member->web); ?></div></td>
        <td class="td-lg"><div class="cell"><?php echo e($member->work); ?></div></td>
        <td class="td-lg"><div><?php echo e($member->organization); ?></div></td>
        <td class="td-lg"><div class="cell"><?php echo e($member->description); ?></div></td>
        <td class="td-lg"><div onClick='copyText(this)' data-toggle="tooltip" title="Copy"  class="cellFb"><?php echo e($member->facebook); ?></div></td>
        <td class="td-lg "><div onClick='copyText(this)' data-toggle="tooltip" title="Copy"  class="cellInsta"><?php echo e($member->instagram); ?></div></td>
        <td class="td-lg">
        <?php if($member->status == 0): ?>
        <span class="label label-primary">Na cekanju</span>
        <?php elseif($member->status == 1): ?>
        <span class="label label-success">Odobreno</span>
        <?php elseif($member->status == 2): ?>
        <span class="label label-danger">Odbijeno</span>
        <?php else: ?>
        <span class="label label-info">Postponed</span>
       <?php endif; ?>
        </td>
        <td class="td-lg">
        <form method="post" action="/update/<?php echo e($member->id); ?>">
            <?php echo e(csrf_field()); ?>

                <div class="form-group">
                    <select name="approve" onchange="this.form.submit()">
                        <option value="0" <?php if($member->status==0): ?>selected <?php endif; ?>>Na cekanju</option>
                        <option value="1" <?php if($member->status==1): ?>selected <?php endif; ?>>Odobri</option>
                        <option value="2" <?php if($member->status==2): ?>selected <?php endif; ?>>Odbij</option>
                        <option value="3" <?php if($member->status==3): ?>selected <?php endif; ?>>Odlozi</option> 
                    </select>
                </div>
                <div class="form-group ">
              <!--   <button type="submit" class="btn btn-success">Update</button> -->
                </div>
            </form>
        </td>
        <td class="td-lg">
        <a href="/members/edit/<?php echo e($member->id); ?>" class="editBtn">Izmjeni</a>
        </td>
        <td>
          
        <?php echo Form::open(['action' => ['MembersController@destroy', $member->id], 'method' => 'POST', 'class' => 'pull-right']); ?>

                <?php echo e(Form::hidden('_method', 'DELETE')); ?>

                <?php echo e(Form::submit('Obriši', ['class' => 'deleteBtn'])); ?>

            <?php echo Form::close(); ?>

        </td>
      </tr>
      <?php  $i++;  ?>
      <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    </tbody>
  </table>
  </div>
</div>
  
</div>

 <?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>