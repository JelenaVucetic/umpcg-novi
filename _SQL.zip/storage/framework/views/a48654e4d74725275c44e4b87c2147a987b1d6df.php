

<?php $__env->startSection('content'); ?>
<section>
<form action="/members/update/<?php echo e($member->id); ?>" method="post"  enctype="multipart/form-data">
    <?php echo e(csrf_field()); ?>

        <div class="contactForm">
            <div>
                <input type="text" name="firstname" placeholder="Ime *" value="<?php echo e($member->firstname); ?> "  required>
                <input type="text" name="lastname" placeholder="Prezime *" value="<?php echo e($member->lastname); ?>" required>
                <input type="text" name="jmbg" placeholder="JMBG *" value="<?php echo e($member->jmbg); ?>" required>
                <input type="text" name="place" placeholder="Mjesto Prebivalista *" value="<?php echo e($member->place); ?>" required>
                <input type="text" name="phone" placeholder="Telefon *" value="<?php echo e($member->phone); ?>" required>
                <input type="email" name="email" placeholder="E-mail *" value="<?php echo e($member->email); ?>" required>              
               <!--  <input id="fileInput" name="image" type="file" style="display:none;"  value="<?php echo e(old('image')); ?>"> -->
                <div id='test' style="padding:0;">
                <input type="file" id="file-upload" name="image"/>
                </div>
                <label  for="file-upload" id="image1"><img src="/img/Upload.svg" alt=""><span> Uploaduj svoj logo </span> <br> <p id="file-upload-filename"></p> </label>
        
            </div>
            <div>
                <input type="text" name="company" placeholder="Naziv firme *"  value="<?php echo e($member->company); ?>">
                <input type="text" name="pib" placeholder="PIB *"  value="<?php echo e($member->pib); ?>">
                <input type="text" name="date" placeholder="Datum osnivanja *"  value="<?php echo e($member->date); ?>">
                <input type="text" name="address" placeholder="Adresa firme *"  value="<?php echo e($member->address); ?>">
                <input type="text" name="web" placeholder="Web adresa"  value="<?php echo e($member->web); ?>">
                <input type="text" name="work" placeholder="Osnovna djelatnost *"  value="<?php echo e($member->work); ?>">
                <input type="text" name="organization" placeholder="Oblik organizacije *"  value="<?php echo e($member->organization); ?>">
            </div>
        </div>
        <textarea name="description" id="" placeholder="Kratak opis vaše kompanije *"><?php echo e($member->description); ?></textarea>
        <div class="textareaLimit">
            <span>220-250 karaktera</span> <span>Unijeto <span id="characters">0 </span>  karatkera</span>
        </div>
        <div class="socialMediaInput">
            <input type="text" name="facebook" placeholder="Facebook stranica" id="facebook"  value="<?php echo e($member->facebook); ?>">
            <input type="text" name="instagram" placeholder="Instagram profile" id="instagram"  value="<?php echo e($member->instagram); ?>">
        </div>
        <div id="submitBtn">
             <button type="submit">Izmijeni</button>
        </div>
    </form>
</section>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>