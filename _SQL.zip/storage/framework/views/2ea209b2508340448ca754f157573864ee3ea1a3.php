

<?php $__env->startSection('content'); ?>
<?php echo Breadcrumbs::render('post', $post); ?>

<section class="singlePostSection">
    <div style='width:100%; word-wrap: break-word;'>
        <img class="singlePost" src="/storage/cover_image/thumbnail/<?php echo e($post->cover_image); ?>">
        <small style="color:#292663">Objavljeno: <?php echo e($post->date); ?>   </small>
        <h1 style="color:#292663; margin: 10px 0;font-size: 28px;"><?php echo e($post->title); ?></h1>
        <div style="display:flex;align-items: center; margin: 25px 0;">
            <small style="white-space:nowrap;"> <img src="/img/Pregledi-ikonica copy.svg" alt=""  style="margin-right: 7px;"> <?php echo e($post->views); ?> pregleda</small>
            <div class="shareBtn">
                <img src="/img/Icons_with_numbers.svg" alt=""><span>Podijeli</span>
                <ul style="list-style:none;">
                    <li><a href=""> <img src="/img/facebook.svg" alt="" style="width:20px;"> </a></li>
                    <li><a href=""> <img src="/img/instagram.svg" alt="" style="width:20px;"> </a></li>
                    <li><a href=""> <img src="/img/twitter.svg" alt="" style="width:20px;"> </a></li>
                </ul>
            </div>
        </div>
        
          <p> <?php echo $post->body; ?></p>
    </div>


    <?php if(!Auth::guest()): ?>
        <?php if(Auth::user()->id == $post->user_id): ?>
            <a href="/posts/<?php echo e($post->id); ?>/edit" class="btn btn-default">Izmjeni</a>

            <?php echo Form::open(['action' => ['PostsController@destroy', $post->id], 'method' => 'POST', 'class' => 'pull-right']); ?>

                <?php echo e(Form::hidden('_method', 'DELETE')); ?>

                <?php echo e(Form::submit('Obriši', ['class' => 'btn btn-danger'])); ?>

            <?php echo Form::close(); ?>

        <?php endif; ?>
    <?php endif; ?>
</section>
<?php $__env->stopSection(); ?>


<?php $__env->startSection('carousel'); ?>
<div class="container-fluid" id="myCarousel" >
<div class="jcarousel-wrapper" id="myCarouselWrapper">
        <div class="jcarousel">
            <ul>
            <?php $__currentLoopData = $posts; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $post): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <li>
                <div class="postBox carouselPost">
                    <a href="/posts/<?php echo e($post->id); ?>">
                        <span class="category" ></span>
                        <small style="color:#292663">Objavljeno: <?php echo e($post->date); ?>  </small>
                        <div id="imgDiv">
                            <img id="postImg" src="/storage/cover_image/thumbnail/<?php echo e($post->cover_image); ?>"  style="max-height:130px;min-height:130px;">
                        </div>
                        <h3 style="font-size: 22px;"><?php echo e($post->title); ?></h3>
                        <div>
                            <small  style="display: flex;"> <img src="/img/Pregledi-ikonica copy.svg" alt="" style="margin-right:7px"><?php echo e($post->views); ?> pregleda</small>     
                       </div>
                    </a>
                </div>
                </li>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?> 
            </ul>
        </div>
        <a href="#" class="jcarousel-control-prev"><img src="/img/Drop down strelica (1).svg" alt=""></a>
        <a href="#" class="jcarousel-control-next"><img src="/img/Ikonica - strelica udesno.svg" alt="" style="width: 25px;"></a>
    </div>
</div>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('breadcrumbs'); ?>
<div class="container-fluid" id='myBreadcrums'>
<!-- <?php echo Breadcrumbs::render('post', $post); ?> -->
</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>