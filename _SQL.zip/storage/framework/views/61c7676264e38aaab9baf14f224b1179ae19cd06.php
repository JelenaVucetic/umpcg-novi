<?php $__env->startSection('members'); ?>
<div class="container" id="breadSection">
<?php echo Breadcrumbs::render('members'); ?>

</div>

<div class="container" id="membersSection">

    <div class="row random">
        <?php $__currentLoopData = $members; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $member): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <div class=" col-lg-3 col-md-4 col-sm-6  company" style="margin-top: 30px;">
                <div class="inner">
                    <div style="padding: 0 10px;">
                        <h4><?php echo e(strtoupper($member->company )); ?></h4>
                    </div>
                    <hr width="25%">
                    <?php if($member->image): ?>
                    <img src="/img/<?php echo e($member->image); ?>" alt="">
                    <?php else: ?> 
                    <img src="/img/icon-no-image.svg" alt="">
                    <?php endif; ?>
                    <div>
                    <div style="position: absolute; bottom: 0; padding:10px;">
                        <p class="description"><?php echo e($member->description); ?></p>
                    </div>
                </div>
                    <div class="overlay">
                        <div class="text">
                            <div id="firstname">
                                <p><?php echo e($member->firstname); ?></p>
                            </div>
                            <div id="work">
                                <p><?php echo e($member->work); ?></p>
                            </div>
                            <div id="member-email">
                                <p><?php echo e($member->email); ?></p>
                            </div>
                            <div id="web"  onClick='copyText(this)' data-toggle="tooltip" title="Copy" >
                                <p><?php echo e($member->web); ?></p>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
    
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    </div>
</div>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('breadcrumbs'); ?>
<div class="container-fluid" id='myBreadcrums'>
    <?php echo Breadcrumbs::render('members'); ?>

</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>