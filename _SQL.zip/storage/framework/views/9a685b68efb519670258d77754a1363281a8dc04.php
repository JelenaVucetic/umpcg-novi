<?php $__env->startSection('content'); ?>
    <h1>Izmijeni članak</h1>
    <?php echo Form::open(['action' => ['PostsController@update', $post->id], 'method' => 'POST', 'enctype' => 'multipart/form-data']); ?>

    <?php echo e(csrf_field()); ?>

         <div class="form-group">
           <?php echo e(Form::label('date', 'Datum')); ?>

            <?php echo e(Form::text('date', $post->date, ['class' => 'form-control', 'placeholder' => 'Unesite datum', 'id' => 'date'])); ?> <br>
        </div>
        <div class="form-group">
            <?php echo e(Form::label('title', 'Naslov')); ?>

            <?php echo e(Form::text('title', $post->title, ['class' => 'form-control', 'placeholder' => 'Naslov'])); ?>

        </div>
        <div class="form-group">
            <?php echo e(Form::label('body', 'Tekst članka')); ?>

            <?php echo e(Form::textarea('body', $post->body, ['id' => 'article-ckeditor', 'class' => 'form-control', 'placeholder' => 'Tekst članka'])); ?>

        </div>
        <div class="form-group">
            <select name="category">
                <option value="umpcg">umpcg</option>
                <option value="ostalo">ostalo</option>
            </select>
        </div>
        <div class="form-group">
            <?php echo e(Form::file('cover_image')); ?>

        </div>
        <?php echo e(Form::hidden('_method','PUT')); ?>

        <?php echo e(Form::submit('Submit', ['class'=>'btn btn-primary'])); ?>

    <?php echo Form::close(); ?>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>