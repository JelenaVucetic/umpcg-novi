

<?php $__env->startSection('content'); ?>
<?php echo Breadcrumbs::render('search'); ?>

<h1>Rezultati pretrage</h1>
   <p>Rezultat(i) za '<?php echo e(request()->input('query')); ?>'</p>
    <?php echo $__env->make('inc.messages', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
    
           <?php 
           //Columns must be a factor of 12 (1,2,3,4,6,12)
           $numOfCols = 3;
           $rowCount = 0;
           $bootstrapColWidth = 12 / $numOfCols;
            ?>
           <div class="row">
            <?php $__empty_1 = true; $__currentLoopData = $posts; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $post): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
            <?php if( $rowCount == 5 ): ?>
               <div class="col-md-<?php  echo $bootstrapColWidth;  ?>" style="padding-top: 30px;">
                   <div class="postBox" style="background:none;box-shadow:none;padding: 70px 30px;">
                       <img src="/img/Baner-EYCA-UMPCG.png" style="border:none; width:100%">    
                   </div>
               </div>
               <?php else: ?>
               <div class="col-md-<?php  echo $bootstrapColWidth;  ?>" style="padding-top: 30px;">
                   <div class="postBox">
                   <span class="category" ></span>
                       <small style="color:#292663">Objavljeno: <?php echo e(\Carbon\Carbon::parse($post->created_at)->format('d.m.Y')); ?>  </small>
                       <div id="imgDiv">
                            <img id="postImg" src="/storage/cover_image/thumbnail/<?php echo e($post->cover_image); ?>">
                        </div>
                       <h3><?php echo e($post->title); ?></h3>
                       <div class="half-a-border-on-top">
                           <small> <img src="/img/Pregledi-ikonica copy.svg" alt=""> 2k pregleda</small>
                           <a href="/posts/<?php echo e($post->id); ?>">Pročitaj vise</a>
                       </div>
                   </div>
               </div>
               <?php endif; ?>
               <?php 
               $rowCount++;
                ?>
              
               <?php if($rowCount % $numOfCols == 0): ?>
                </div><div class="row">
               <?php endif; ?>
               <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                <p style="padding-left:20px;">Nije pronađen ni jedan članak.</p>
            <?php endif; ?>
           </div>
        <?php echo e($posts->links()); ?>


<?php $__env->stopSection(); ?>
<?php $__env->startSection('breadcrumbs'); ?>
<div class="container-fluid" id='myBreadcrums'>
    <?php echo Breadcrumbs::render('search'); ?>

</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>