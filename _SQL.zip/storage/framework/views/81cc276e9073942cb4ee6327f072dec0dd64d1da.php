<?php $__env->startSection('boostrap-script'); ?>
<script src="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/js/bootstrap.min.js" integrity="sha384-Tc5IQib027qvyjSMfHjOMaLkfuWVxZxUPnCJA7l2mCWNIpG9mGCD8wGNIcPD7Txa" crossorigin="anonymous"></script>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>
    <?php echo $__env->make('inc.admin_nav', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
<!--   Modal form -->
<div id="delete" class="modal fade" tabindex="-1" role="dialog" aria-labelledby="mySmallModalLabel" aria-hidden="true">
  <div class="modal-dialog modal-sm">
    <div class="modal-content" id="test">
        <h5>Da li ste sigurni da želite da obrišete objavu?</h5>
        <div>
        <form action="<?php echo e(route('posts.destroy', 'test')); ?>" method="POST">    
                <?php echo e(Form::hidden('_method', 'DELETE')); ?>

                <?php echo e(csrf_field()); ?>

                <input type="hidden" id="p_id" name="post_id" value=" ">
                <?php echo e(Form::submit('Obriši', ['class' => 'deleteBtn'])); ?>

            </form>
            <button type="button" data-dismiss="modal" aria-label="Close" >Zatvori</button>
        </div>
        
    </div>
  </div>
</div>

<div class="post-table"> 
    <a href="/posts/create" class="btn addPostBtn"><i style="color:white" class="fa fa-plus addPostIco"></i> <span class="addPost">Nova objava</span> </a>
    <?php if(count($posts) > 0): ?>
        <table class="table table-striped">
            <tr>
                <th>Datum</th>
                <th>Naslov</th>
                <th>Akcija</th>
                <th></th>
            </tr>
            <?php $__currentLoopData = $posts; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $post): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <tr>
                    <td><?php echo e($post->date); ?></td>
                    <td><a href="/posts/<?php echo e($post->id); ?>"><?php echo e($post->title); ?></a></td>
                    <td><a class="editBtn" href="/posts/<?php echo e($post->id); ?>/edit" class="btn btn-default">Izmijeni</a></td>
                    <td>
                        <button type="button" class="deleteBtn"  data-post="<?php echo e($post->id); ?>" data-toggle="modal" data-target="#delete">Obriši</button>
                   </td>
                </tr>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </table>
    <?php else: ?>
        <p>You have no posts</p>
    <?php endif; ?>
</div>

<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>